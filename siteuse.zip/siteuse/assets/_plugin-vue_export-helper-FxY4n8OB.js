const r="/assets/fcs-VT-63yFB.webp",_=(s,o)=>{const t=s.__vccOpts||s;for(const[c,e]of o)t[c]=e;return t};export{_,r as a};
